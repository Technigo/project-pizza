# Project Name

In this project I made a pizza ordering system with javascript, using browser alert/prompt popups to get input in form of multiple choice, YES/NO, Ok, cancel. 

## The problem

The challenge was to write the code corectly in order to get it working in the browser. More often there were missing brackets or wrongly assigned variables that resulted in the code not being executed / or stuck at a certain stage. 

## View it live

The deployed version can be viewed here: 
